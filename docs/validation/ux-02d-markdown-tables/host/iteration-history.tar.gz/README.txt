Iteration logs retained for transparency. They are not the final acceptance results.
Some focused runs initially failed on an import or test expectation while the table renderer/test was being refined; the final focused and proportional gates are recorded separately at the current source SHA.
The directory focused-junit-after-compile-failure-stale contains result XML copied by the wrapper after a Kotlin compile failure; those XML files are from the preceding run and MUST NOT be attributed to that failed attempt.
The earlier full gate used application code SHA df8aeb26 before the final host-test-only adjustment. The final full gate is the e97a5a1 source run recorded separately.
